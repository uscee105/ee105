#include <arm_math.h>
#include <Arduino_APDS9960.h>
#include <Arduino_LPS22HB.h>
#include <Arduino_LSM9DS1.h>
#include <PDM.h>

#include <ArduinoBLE.h>

#define BLE_SENSE_UUID(val) ("6fbe1da7-" val "-44de-92c4-bb6e04fb0212")

const int VERSION = 0x00000000;

BLEService                     service                       (BLE_SENSE_UUID("0000"));
BLEUnsignedIntCharacteristic   versionCharacteristic         (BLE_SENSE_UUID("1001"), BLERead);
BLEUnsignedShortCharacteristic ambientLightCharacteristic    (BLE_SENSE_UUID("2001"), BLENotify);
BLECharacteristic              colorCharacteristic           (BLE_SENSE_UUID("2002"), BLENotify, 3 * sizeof(unsigned short));
BLEUnsignedCharCharacteristic  proximityCharacteristic       (BLE_SENSE_UUID("2003"), BLENotify);
BLEByteCharacteristic          gestureCharacteristic         (BLE_SENSE_UUID("2004"), BLENotify);
BLECharacteristic              accelerationCharacteristic    (BLE_SENSE_UUID("3001"), BLENotify, 3 * sizeof(float));
BLECharacteristic              gyroscopeCharacteristic       (BLE_SENSE_UUID("3002"), BLENotify, 3 * sizeof(float));
BLECharacteristic              magneticFieldCharacteristic   (BLE_SENSE_UUID("3003"), BLENotify, 3 * sizeof(float));

BLEFloatCharacteristic         pressureCharacteristic        (BLE_SENSE_UUID("4001"), BLERead);
BLECharacteristic              microphoneLevelCharacteristic (BLE_SENSE_UUID("5001"), BLENotify, 32);
BLECharacteristic              rgbLedCharacteristic          (BLE_SENSE_UUID("6001"), BLERead | BLEWrite, 3 * sizeof(byte));

String name;
short sampleBuffer[256];
arm_rfft_instance_q15 FFT;
volatile int samplesRead;

void setup() {
  Serial.begin(9600);

  Serial.println("Started");

  if (!APDS.begin()) {
    Serial.println("Failed to initialize APDS!");
    while (1);
  }

  if (!BARO.begin()) {
    Serial.println("Failed to initialize BARO!");
    while (1);
  }

  if (!IMU.begin()) {
    Serial.println("Failed to initialize IMU!");
    while (1);
  }

  PDM.onReceive(onPDMdata);

  if (!PDM.begin(1, 16000)) {
    Serial.println("Failed to start PDM!");
    while (1);
  }

  if (!BLE.begin()) {
    Serial.println("Failed to initialize BLE!");
    while (1);
  }

  String address = BLE.address();
  Serial.print("address = ");
  Serial.println(address);
  address.toUpperCase();

  name = "BLESense-";
  name += address[address.length() - 5];
  name += address[address.length() - 4];
  name += address[address.length() - 2];
  name += address[address.length() - 1];

  Serial.print("name = ");
  Serial.println(name);

  BLE.setLocalName(name.c_str());
  BLE.setDeviceName(name.c_str());
  BLE.setAdvertisedService(service);

  service.addCharacteristic(versionCharacteristic);
  service.addCharacteristic(ambientLightCharacteristic);
  service.addCharacteristic(colorCharacteristic);
  service.addCharacteristic(proximityCharacteristic);
  service.addCharacteristic(gestureCharacteristic);
  service.addCharacteristic(accelerationCharacteristic);
  service.addCharacteristic(gyroscopeCharacteristic);
  service.addCharacteristic(magneticFieldCharacteristic);
  service.addCharacteristic(pressureCharacteristic);
  service.addCharacteristic(microphoneLevelCharacteristic);
  service.addCharacteristic(rgbLedCharacteristic);

  versionCharacteristic.setValue(VERSION);
  pressureCharacteristic.setEventHandler(BLERead, onPressureCharacteristicRead);
  rgbLedCharacteristic.setEventHandler(BLEWritten, onRgbLedCharacteristicWrite);

  BLE.addService(service);
  BLE.advertise();
}

void loop() {
  while (BLE.connected()) {
    if ((ambientLightCharacteristic.subscribed() || colorCharacteristic.subscribed()) && APDS.colorAvailable()) {
      int r, g, b, ambientLight;

      APDS.readColor(r, g, b, ambientLight);

      ambientLightCharacteristic.writeValue(ambientLight);

      unsigned short colors[3] = { r, g, b };

      colorCharacteristic.writeValue(colors, sizeof(colors));
    }

    if (proximityCharacteristic.subscribed() && APDS.proximityAvailable()) {
      int proximity = APDS.readProximity();

      proximityCharacteristic.writeValue(proximity);
    }

    if (gestureCharacteristic.subscribed() && APDS.gestureAvailable()) {
      int gesture = APDS.readGesture();

      gestureCharacteristic.writeValue(gesture);
    }

    if (accelerationCharacteristic.subscribed() && IMU.accelerationAvailable()) {
      float x, y, z;

      IMU.readAcceleration(x, y, z);

      float acceleration[3] = { x, y, z };

      accelerationCharacteristic.writeValue(acceleration, sizeof(acceleration));
    }

    if (gyroscopeCharacteristic.subscribed() && IMU.gyroscopeAvailable()) {
      float x, y, z;

      IMU.readGyroscope(x, y, z);

      float dps[3] = { x, y, z };

      gyroscopeCharacteristic.writeValue(dps, sizeof(dps));
    }

    if (magneticFieldCharacteristic.subscribed() && IMU.magneticFieldAvailable()) {
      float x, y, z;

      IMU.readMagneticField(x, y, z);

      float magneticField[3] = { x, y, z };

      magneticFieldCharacteristic.writeValue(magneticField, sizeof(magneticField));
    }

    if (microphoneLevelCharacteristic.subscribed() && samplesRead) {
      short micLevel;

      static arm_rfft_instance_q15 fft_instance;
      static q15_t fftoutput[256 * 2];
      static byte spectrum[32];
      arm_rfft_init_q15(&fft_instance, 256, 0, 1);
      arm_rfft_q15(&fft_instance, (q15_t*)sampleBuffer, fftoutput);
      arm_abs_q15(fftoutput, fftoutput, 256);

      float temp = 0;
      for (int i = 1; i < 256; i++) {
        temp = temp + fftoutput[i];
        if ((i & 3) == 2) {
          if (temp > 1023) { temp = 1023; };
          spectrum[i >> 3] = (byte)(temp / 2);
          temp = 0;
        }
      }
      microphoneLevelCharacteristic.writeValue((byte *)&spectrum, 32);
      samplesRead = 0;
    }

    // Check for Serial input to control RGB LED
    if (Serial.available()) {
      String input = Serial.readStringUntil('\n');
      input.trim();

      int commaIndex1 = input.indexOf(',');
      int commaIndex2 = input.indexOf(',', commaIndex1 + 1);

      if (commaIndex1 > 0 && commaIndex2 > commaIndex1) {
        int r = input.substring(0, commaIndex1).toInt();
        int g = input.substring(commaIndex1 + 1, commaIndex2).toInt();
        int b = input.substring(commaIndex2 + 1).toInt();

        // Set the RGB LED
        setLedPinValue(LEDR, r);
        setLedPinValue(LEDG, g);
        setLedPinValue(LEDB, b);

        Serial.print("RGB LED set to: R=");
        Serial.print(r);
        Serial.print(", G=");
        Serial.print(g);
        Serial.print(", B=");
        Serial.println(b);
      } else {
        Serial.println("Invalid input format. Please enter values in R,G,B format.");
      }
    }
  }
}

void onPressureCharacteristicRead(BLEDevice central, BLECharacteristic characteristic) {
  float pressure = BARO.readPressure();
  pressureCharacteristic.writeValue(pressure);
}

void onRgbLedCharacteristicWrite(BLEDevice central, BLECharacteristic characteristic) {
  byte r = rgbLedCharacteristic[0];
  byte g = rgbLedCharacteristic[1];
  byte b = rgbLedCharacteristic[2];

  setLedPinValue(LEDR, r);
  setLedPinValue(LEDG, g);
  setLedPinValue(LEDB, b);
}

void setLedPinValue(int pin, int value) {
  if (value == 0) {
    analogWrite(pin, 256);
  } else {
    analogWrite(pin, 255 - value);
  }
}

void onPDMdata() {
  int bytesAvailable = PDM.available();
  PDM.read(sampleBuffer, bytesAvailable);
  samplesRead = bytesAvailable / 2;
}