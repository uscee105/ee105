#include <Arduino_LPS22HB.h>

void setup() {
  Serial.begin(9600);

  // Initialize LPS22HB pressure sensor
  if (!BARO.begin()) {
    Serial.println("Failed to initialize pressure sensor!");
    while (1);
  }
  Serial.println("Pressure sensor initialized successfully!");
}

void loop() {
  // Read and print pressure value
  float pressure = BARO.readPressure();
  Serial.print("Pressure: ");
  Serial.print(pressure);
  Serial.println(" kPa");

  delay(1000); // Delay to make it easier to read the output
}