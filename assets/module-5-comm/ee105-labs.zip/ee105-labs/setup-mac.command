#!/bin/bash
# =====================================================================
#  EE 105 lab kit: setup and start for macOS 12 or newer (Apple Silicon and Intel)
#
#  Start it from Terminal:  bash setup-mac.command   (type "bash ", drag this file into the
#  Terminal window, press Return). That works on every Mac. A double-click works too if the kit was
#  downloaded with curl (the Terminal command on the course calendar); a copy downloaded with a web
#  browser is blocked by macOS on double-click.
#
#  First run (15 to 30 minutes, about 5 GB download and disk space, no administrator password):
#    1. finds conda (Miniforge, Miniconda or Anaconda) or installs Miniforge in ~/miniforge3
#    2. creates the conda environment "ee105" from environment.yml
#    3. installs the Arduino tools and the Nano 33 BLE board package
#    4. starts JupyterLab in this folder
#  Later runs only start JupyterLab (a few seconds). If environment.yml changed, the environment
#  is updated first. Every step is written to setup-log.txt in this folder.
# =====================================================================
set -u

cd "$(dirname "$0")" || exit 1
KIT="$(pwd)"
LOG="$KIT/setup-log.txt"
ENV_NAME="ee105"
ENV_FILE="$KIT/environment.yml"
MINIFORGE_DIR="${EE105_MINIFORGE_DIR:-$HOME/miniforge3}"
MINIFORGE_BASE_URL="${EE105_MINIFORGE_BASE_URL:-https://github.com/conda-forge/miniforge/releases/latest/download}"
NEED_GB=6

say() {
    echo "$*"
    echo "$(date '+%Y-%m-%d %H:%M:%S')  $*" >> "$LOG"
}

pause_window() {
    if [ -t 0 ] && [ -z "${EE105_NO_PAUSE:-}" ]; then
        echo ""
        read -r -p "Press Enter to close this window." _
    fi
}

fail() {
    say ""
    say "SETUP STOPPED: $1"
    say "Details are in setup-log.txt in the lab kit folder. Fix the problem, then run"
    say "setup-mac.command again the same way; finished steps are not repeated."
    pause_window
    exit 1
}

free_gb() {     # free space (GB, rounded down) on the disk that holds the folder $1
    df -Pk "$1" 2>/dev/null | awk 'NR == 2 { print int($4 / 1048576) }'
}

online() {
    curl -s -o /dev/null -I --max-time 20 "https://conda.anaconda.org/conda-forge/" ||
        curl -s -o /dev/null -I --max-time 20 "https://github.com/"
}

find_conda() {      # sets CONDA_BASE to a conda installation, or returns 1
    CONDA_BASE=""
    for d in "$MINIFORGE_DIR" "$HOME/miniforge3" "$HOME/mambaforge" "$HOME/miniconda3" "$HOME/anaconda3" \
             "$HOME/opt/miniforge3" "$HOME/opt/miniconda3" "$HOME/opt/anaconda3" \
             "/opt/homebrew/Caskroom/miniforge/base" "/usr/local/Caskroom/miniforge/base" \
             "/opt/homebrew/Caskroom/miniconda/base" "/usr/local/Caskroom/miniconda/base" \
             "/opt/miniconda3" "/opt/anaconda3" "/usr/local/miniconda3" "/usr/local/anaconda3"; do
        if [ -x "$d/bin/conda" ] && [ -f "$d/etc/profile.d/conda.sh" ]; then
            CONDA_BASE="$d"
            return 0
        fi
    done
    if command -v conda >/dev/null 2>&1; then
        d="$(conda info --base 2>/dev/null)"
        if [ -n "$d" ] && [ -f "$d/etc/profile.d/conda.sh" ]; then
            CONDA_BASE="$d"
            return 0
        fi
    fi
    return 1
}

start_jupyter() {
    say ""
    say "Starting JupyterLab in your web browser. Keep this window open while you work;"
    say "close the browser tab and press Control-C here (twice) when you are done."
    cd "$KIT" || exit 1
    jupyter lab
    exit 0
}

echo "" >> "$LOG"
say "EE 105 lab kit setup (macOS $(sw_vers -productVersion 2>/dev/null || uname -r), $(uname -m))"
say "Lab kit folder: $KIT"
[ -f "$ENV_FILE" ] || fail "environment.yml is missing. Unzip the whole lab kit and run this file from its folder."

# ---- fast path: everything is already set up ------------------------------------------------
if find_conda; then
    # shellcheck disable=SC1091
    source "$CONDA_BASE/etc/profile.d/conda.sh"
    if conda activate "$ENV_NAME" 2>> "$LOG"; then
        if cmp -s "$ENV_FILE" "$CONDA_PREFIX/ee105-environment.yml" && [ -f "$CONDA_PREFIX/ee105-arduino.ok" ]; then
            say "[ok] Everything is set up (conda in $CONDA_BASE, environment $ENV_NAME)."
            start_jupyter
        fi
        conda deactivate
    fi
fi

# ---- 1. conda ----------------------------------------------------------------------------------
if find_conda; then
    say "[ok] Step 1 of 4: found conda in $CONDA_BASE"
else
    say "Step 1 of 4: installing Miniforge (conda) in $MINIFORGE_DIR ..."
    online || fail "No internet connection. Connect to the internet (USC Secure Wireless or eduroam work) and try again."
    gb="$(free_gb "$HOME")"
    if [ -n "$gb" ] && [ "$gb" -lt "$NEED_GB" ]; then
        fail "Only $gb GB free on your disk; the lab kit needs about $NEED_GB GB. Free some space and try again."
    fi
    if [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then arch="arm64"; else arch="x86_64"; fi
    installer="${TMPDIR:-/tmp}/Miniforge3-MacOSX-$arch.sh"
    say "     downloading Miniforge3-MacOSX-$arch.sh ..."
    curl -fsSL --retry 3 -o "$installer" "$MINIFORGE_BASE_URL/Miniforge3-MacOSX-$arch.sh" >> "$LOG" 2>&1 ||
        fail "Could not download Miniforge. Check the internet connection and try again."
    say "     installing (2 to 5 minutes) ..."
    bash "$installer" -b -u -p "$MINIFORGE_DIR" >> "$LOG" 2>&1 || {
        gb="$(free_gb "$HOME")"
        [ -n "$gb" ] && [ "$gb" -lt 1 ] && fail "The disk is full. Free some space and try again."
        fail "The Miniforge installer failed (see setup-log.txt)."
    }
    rm -f "$installer"
    find_conda || fail "Miniforge was installed but conda was not found in $MINIFORGE_DIR."
    say "[ok] Step 1 of 4: installed Miniforge in $CONDA_BASE"
fi
# shellcheck disable=SC1091
source "$CONDA_BASE/etc/profile.d/conda.sh" || fail "Could not load conda from $CONDA_BASE."

# ---- 2. the ee105 environment ----------------------------------------------------------------
online || fail "No internet connection. Connect to the internet and try again."
gb="$(free_gb "$CONDA_BASE")"
if [ -n "$gb" ] && [ "$gb" -lt 4 ]; then
    fail "Only $gb GB free on your disk; the Python environment needs about 4 GB. Free some space and try again."
fi
if conda activate "$ENV_NAME" 2>> "$LOG"; then
    conda deactivate
    say "Step 2 of 4: updating the Python environment \"$ENV_NAME\" (a few minutes) ..."
    conda env update -n "$ENV_NAME" -f "$ENV_FILE" --prune >> "$LOG" 2>&1 || env_failed=1
else
    say "Step 2 of 4: creating the Python environment \"$ENV_NAME\" (10 to 20 minutes, about 3 GB) ..."
    say "     Progress goes to setup-log.txt; this window stays quiet until it is done."
    conda env create -n "$ENV_NAME" -f "$ENV_FILE" >> "$LOG" 2>&1 || env_failed=1
fi
if [ -n "${env_failed:-}" ]; then
    gb="$(free_gb "$CONDA_BASE")"
    [ -n "$gb" ] && [ "$gb" -lt 1 ] && fail "The disk is full. Free some space and try again."
    online || fail "The internet connection dropped during the download. Try again."
    fail "conda could not create the environment \"$ENV_NAME\" (see the end of setup-log.txt)."
fi
conda activate "$ENV_NAME" || fail "The environment \"$ENV_NAME\" was created but cannot be activated."
cp "$ENV_FILE" "$CONDA_PREFIX/ee105-environment.yml"
say "[ok] Step 2 of 4: Python environment \"$ENV_NAME\" in $CONDA_PREFIX"

# ---- 3. Arduino tools ------------------------------------------------------------------------
say "Step 3 of 4: installing the Arduino tools and the Nano 33 BLE board package (5 to 10 minutes) ..."
if python -m ee105 setup >> "$LOG" 2>&1; then
    touch "$CONDA_PREFIX/ee105-arduino.ok"
    say "[ok] Step 3 of 4: Arduino tools installed"
else
    say "[!!] Step 3 of 4: the Arduino tools did not install (see setup-log.txt). The first lab"
    say "     notebook that uses the board tries again, or run this file again later."
fi

# ---- 4. JupyterLab -----------------------------------------------------------------------------
say "[ok] Step 4 of 4: setup complete."
start_jupyter
