#!/bin/bash
# =====================================================================
#  EE 105 lab kit: setup and start for macOS 12 or newer (Apple Silicon and Intel)
#
#  Start it from Terminal:  bash setup-mac.command   (type "bash ", drag this file into the
#  Terminal window, press Return). That works on every Mac. A double-click works too if the kit was
#  downloaded with curl (the Terminal command on the course calendar); a copy downloaded with a web
#  browser is blocked by macOS on double-click.
#
#  First run (15 to 30 minutes, about 5 GB download and disk space, no administrator password):
#    1. finds conda (Miniforge, Miniconda or Anaconda) or installs Miniforge in ~/miniforge3
#    2. creates the conda environment "ee105" from environment.yml. A kit without a Module 4
#       lab folder (lab4.1, lab4.2), such as the LiFi kit, uses environment-lite.yml: no PyTorch,
#       5 to 15 minutes and about 2.5 GB in all. An "ee105" environment that already has the
#       packages is used as it is.
#    3. installs the Arduino tools and the Nano 33 BLE board package
#    4. starts JupyterLab in this folder
#  Later runs only start JupyterLab (a few seconds). If environment.yml changed, the environment
#  is updated first. Every step is written to setup-log.txt in this folder.
# =====================================================================
set -u

cd "$(dirname "$0")" || exit 1
KIT="$(pwd)"
LOG="$KIT/setup-log.txt"
ENV_NAME="ee105"
ENV_FILE="$KIT/environment.yml"
MINIFORGE_DIR="${EE105_MINIFORGE_DIR:-$HOME/miniforge3}"
MINIFORGE_BASE_URL="${EE105_MINIFORGE_BASE_URL:-https://github.com/conda-forge/miniforge/releases/latest/download}"
NEED_GB=6
ENV_GB=4
ENV_NOTE="10 to 20 minutes, about 3 GB"
PRUNE="--prune"
LITE=""
# A kit without a Module 4 lab (the neural-network labs need PyTorch) gets the small environment.
if [ -f "$KIT/environment-lite.yml" ] && ! ls -d "$KIT"/lab4.* >/dev/null 2>&1; then
    LITE=1
    ENV_FILE="$KIT/environment-lite.yml"
    NEED_GB=3
    ENV_GB=2
    ENV_NOTE="3 to 8 minutes, about 1 GB"
    PRUNE=""        # never remove packages (PyTorch from an earlier lab) from an existing environment
fi

say() {
    echo "$*"
    echo "$(date '+%Y-%m-%d %H:%M:%S')  $*" >> "$LOG"
}

pause_window() {
    if [ -t 0 ] && [ -z "${EE105_NO_PAUSE:-}" ]; then
        echo ""
        read -r -p "Press Enter to close this window." _
    fi
}

fail() {
    say ""
    say "SETUP STOPPED: $1"
    say "Details are in setup-log.txt in the lab kit folder. Fix the problem, then run"
    say "setup-mac.command again the same way; finished steps are not repeated."
    pause_window
    exit 1
}

free_gb() {     # free space (GB, rounded down) on the disk that holds the folder $1
    df -Pk "$1" 2>/dev/null | awk 'NR == 2 { print int($4 / 1048576) }'
}

online() {
    curl -s -o /dev/null -I --max-time 20 "https://conda.anaconda.org/conda-forge/" ||
        curl -s -o /dev/null -I --max-time 20 "https://github.com/"
}

find_conda() {      # sets CONDA_BASE to a conda installation, or returns 1
    CONDA_BASE=""
    for d in "$MINIFORGE_DIR" "$HOME/miniforge3" "$HOME/mambaforge" "$HOME/miniconda3" "$HOME/anaconda3" \
             "$HOME/opt/miniforge3" "$HOME/opt/miniconda3" "$HOME/opt/anaconda3" \
             "/opt/homebrew/Caskroom/miniforge/base" "/usr/local/Caskroom/miniforge/base" \
             "/opt/homebrew/Caskroom/miniconda/base" "/usr/local/Caskroom/miniconda/base" \
             "/opt/miniconda3" "/opt/anaconda3" "/usr/local/miniconda3" "/usr/local/anaconda3"; do
        if [ -x "$d/bin/conda" ] && [ -f "$d/etc/profile.d/conda.sh" ]; then
            CONDA_BASE="$d"
            return 0
        fi
    done
    if command -v conda >/dev/null 2>&1; then
        d="$(conda info --base 2>/dev/null)"
        if [ -n "$d" ] && [ -f "$d/etc/profile.d/conda.sh" ]; then
            CONDA_BASE="$d"
            return 0
        fi
    fi
    return 1
}

install_miniforge() {     # installs Miniforge in $MINIFORGE_DIR and sets CONDA_BASE to it
    online || fail "No internet connection. Connect to the internet (USC Secure Wireless or eduroam work) and try again."
    gb="$(free_gb "$HOME")"
    if [ -n "$gb" ] && [ "$gb" -lt "$NEED_GB" ]; then
        fail "Only $gb GB free on your disk; the lab kit needs about $NEED_GB GB. Free some space and try again."
    fi
    if [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then arch="arm64"; else arch="x86_64"; fi
    installer="${TMPDIR:-/tmp}/Miniforge3-MacOSX-$arch.sh"
    say "     downloading Miniforge3-MacOSX-$arch.sh ..."
    curl -fsSL --retry 3 -o "$installer" "$MINIFORGE_BASE_URL/Miniforge3-MacOSX-$arch.sh" >> "$LOG" 2>&1 ||
        fail "Could not download Miniforge. Check the internet connection and try again."
    say "     installing (2 to 5 minutes) ..."
    bash "$installer" -b -u -p "$MINIFORGE_DIR" >> "$LOG" 2>&1 || {
        gb="$(free_gb "$HOME")"
        [ -n "$gb" ] && [ "$gb" -lt 1 ] && fail "The disk is full. Free some space and try again."
        fail "The Miniforge installer failed (see setup-log.txt)."
    }
    rm -f "$installer"
    if [ -x "$MINIFORGE_DIR/bin/conda" ] && [ -f "$MINIFORGE_DIR/etc/profile.d/conda.sh" ]; then
        CONDA_BASE="$MINIFORGE_DIR"
    else
        fail "Miniforge was installed but conda was not found in $MINIFORGE_DIR."
    fi
}

use_env() {     # activate the environment and make sure its programs come first on the PATH
    conda activate "$ENV_NAME" 2>> "$LOG" || return 1
    # another Python earlier on the PATH (MacPorts, Homebrew, pyenv) must not win
    PATH="$CONDA_PREFIX/bin:$PATH"
    export PATH
    hash -r
}

env_ok() {      # the active environment has what this kit needs
    cmp -s "$ENV_FILE" "$CONDA_PREFIX/ee105-environment.yml" && return 0
    # small kit: an environment made earlier (for example by the full kit) is fine if it has the packages
    [ -n "$LITE" ] && python -c "import numpy, pandas, matplotlib, scipy, sympy, serial, jupyterlab" >> "$LOG" 2>&1
}

start_jupyter() {
    say ""
    say "Starting JupyterLab in your web browser. Keep this window open while you work;"
    say "close the browser tab and press Control-C here (twice) when you are done."
    cd "$KIT" || exit 1
    jupyter lab
    exit 0
}

echo "" >> "$LOG"
say "EE 105 lab kit setup (macOS $(sw_vers -productVersion 2>/dev/null || uname -r), $(uname -m))"
say "Lab kit folder: $KIT"
[ -n "$LITE" ] && say "Small kit (no Module 4 lab): using environment-lite.yml, without PyTorch."
[ -f "$ENV_FILE" ] || fail "environment.yml is missing. Unzip the whole lab kit and run this file from its folder."

# ---- fast path: everything is already set up ------------------------------------------------
if find_conda; then
    # shellcheck disable=SC1091
    source "$CONDA_BASE/etc/profile.d/conda.sh"
    if use_env; then
        if env_ok && [ -f "$CONDA_PREFIX/ee105-arduino.ok" ]; then
            say "[ok] Everything is set up (conda in $CONDA_BASE, environment $ENV_NAME)."
            start_jupyter
        fi
        conda deactivate
    fi
fi

# ---- 1. conda ----------------------------------------------------------------------------------
if find_conda; then
    say "[ok] Step 1 of 4: found conda in $CONDA_BASE"
else
    say "Step 1 of 4: installing Miniforge (conda) in $MINIFORGE_DIR ..."
    install_miniforge
    say "[ok] Step 1 of 4: installed Miniforge in $CONDA_BASE"
fi
# shellcheck disable=SC1091
source "$CONDA_BASE/etc/profile.d/conda.sh" || fail "Could not load conda from $CONDA_BASE."

# ---- 2. the ee105 environment ----------------------------------------------------------------
online || fail "No internet connection. Connect to the internet and try again."
gb="$(free_gb "$CONDA_BASE")"
if [ -n "$gb" ] && [ "$gb" -lt "$ENV_GB" ]; then
    fail "Only $gb GB free on your disk; the Python environment needs about $ENV_GB GB. Free some space and try again."
fi
CONDA_OUT="${TMPDIR:-/tmp}/ee105-conda-output.txt"
make_env() {    # creates or updates the environment with the conda in CONDA_BASE; sets env_failed, have_env
    env_failed=""
    have_env=""
    : > "$CONDA_OUT"
    if use_env; then
        if env_ok; then have_env=1; fi
        conda deactivate
        if [ -n "$have_env" ]; then
            say "     The environment \"$ENV_NAME\" already has the packages; nothing to download."
        else
            say "Step 2 of 4: updating the Python environment \"$ENV_NAME\" (a few minutes) ..."
            # shellcheck disable=SC2086
            conda env update -n "$ENV_NAME" -f "$ENV_FILE" $PRUNE > "$CONDA_OUT" 2>&1 || env_failed=1
        fi
    else
        say "Step 2 of 4: creating the Python environment \"$ENV_NAME\" ($ENV_NOTE) ..."
        say "     This window stays quiet until it is done; the details go to setup-log.txt."
        conda env create -n "$ENV_NAME" -f "$ENV_FILE" > "$CONDA_OUT" 2>&1 || env_failed=1
    fi
    cat "$CONDA_OUT" >> "$LOG"
}

make_env
# Anaconda and Miniconda refuse to work until Anaconda's Terms of Service are accepted. The lab kit
# takes all its packages from conda-forge, so it uses its own Miniforge instead of asking for that.
if [ -n "$env_failed" ] && grep -q "CondaToS" "$CONDA_OUT" && [ "$CONDA_BASE" != "$MINIFORGE_DIR" ]; then
    say "     The conda in $CONDA_BASE (Anaconda or Miniconda) first wants Anaconda's Terms of"
    say "     Service accepted. The lab kit does not need Anaconda's packages: it installs its own"
    say "     Miniforge in $MINIFORGE_DIR and uses that. Your other conda is not changed."
    conda deactivate >/dev/null 2>&1
    install_miniforge
    # shellcheck disable=SC1091
    source "$CONDA_BASE/etc/profile.d/conda.sh" || fail "Could not load conda from $CONDA_BASE."
    make_env
fi
rm -f "$CONDA_OUT"
if [ -n "$env_failed" ]; then
    gb="$(free_gb "$CONDA_BASE")"
    [ -n "$gb" ] && [ "$gb" -lt 1 ] && fail "The disk is full. Free some space and try again."
    online || fail "The internet connection dropped during the download. Try again."
    fail "conda could not create the environment \"$ENV_NAME\" (see the end of setup-log.txt)."
fi
use_env || fail "The environment \"$ENV_NAME\" was created but cannot be activated."
# record which file the environment matches; an environment kept as it was keeps its own record
[ -n "$have_env" ] || cp "$ENV_FILE" "$CONDA_PREFIX/ee105-environment.yml"
say "[ok] Step 2 of 4: Python environment \"$ENV_NAME\" in $CONDA_PREFIX"

# ---- 3. Arduino tools ------------------------------------------------------------------------
say "Step 3 of 4: installing the Arduino tools and the Nano 33 BLE board package (5 to 10 minutes) ..."
if python -m ee105 setup >> "$LOG" 2>&1; then
    touch "$CONDA_PREFIX/ee105-arduino.ok"
    say "[ok] Step 3 of 4: Arduino tools installed"
else
    say "[!!] Step 3 of 4: the Arduino tools did not install (see setup-log.txt). The first lab"
    say "     notebook that uses the board tries again, or run this file again later."
fi

# ---- 4. JupyterLab -----------------------------------------------------------------------------
say "[ok] Step 4 of 4: setup complete."
start_jupyter
