@echo off
rem =====================================================================
rem  EE 105 lab kit: setup and start for Windows 10 and 11 (x64; ARM64 on Windows 11)
rem
rem  Double-click this file. If Windows shows "Windows protected your PC", click
rem  "More info", then "Run anyway".
rem
rem  First run (15 to 30 minutes, about 5 GB of disk space, no administrator rights):
rem    1. finds conda (Miniforge, Miniconda or Anaconda) or installs Miniforge in your user folder
rem    2. creates the conda environment "ee105" from environment.yml. A kit without a Module 4
rem       lab folder (lab4.1, lab4.2), such as the LiFi kit, uses environment-lite.yml: no PyTorch,
rem       5 to 15 minutes and about 2.5 GB in all. An "ee105" environment that already has the
rem       packages is used as it is.
rem    3. installs the Arduino tools and the Nano 33 BLE board package
rem    4. starts JupyterLab in this folder
rem  Later runs only start JupyterLab (a few seconds). If environment.yml changed, the environment
rem  is updated first. Every step is written to setup-log.txt in this folder.
rem =====================================================================
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
set "KIT=%CD%"
set "LOG=%KIT%\setup-log.txt"
set "ENV_NAME=ee105"
set "ENV_FILE=%KIT%\environment.yml"
set "MINIFORGE_URL=https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Windows-x86_64.exe"
set "CONDA_BASE="
set "ENV_FAILED="
set "HAVE_ENV="
set "TOS_RETRY="
set "CONDA_OUT=%TEMP%\ee105-conda-output.txt"
set "NEED_GB=6"
set "ENV_GB=4"
set "ENV_NOTE=10 to 20 minutes, about 3 GB"
set "PRUNE=--prune"
set "LITE="
rem A kit without a Module 4 lab (the neural-network labs need PyTorch) gets the small environment.
if not exist "%KIT%\environment-lite.yml" goto :kit_chosen
if exist "%KIT%\lab4.*" goto :kit_chosen
set "LITE=1"
set "ENV_FILE=%KIT%\environment-lite.yml"
set "NEED_GB=3"
set "ENV_GB=2"
set "ENV_NOTE=3 to 8 minutes, about 1 GB"
rem never remove packages (PyTorch from an earlier lab) from an existing environment
set "PRUNE="
:kit_chosen

rem Miniforge does not like spaces in its folder; use C:\miniforge3-ee105 if the user folder has one.
set "MINIFORGE_DIR=%USERPROFILE%\miniforge3"
if not "%USERPROFILE: =%"=="%USERPROFILE%" set "MINIFORGE_DIR=%SystemDrive%\miniforge3-ee105"
if defined EE105_MINIFORGE_DIR set "MINIFORGE_DIR=%EE105_MINIFORGE_DIR%"

>>"%LOG%" echo.
call :say "EE 105 lab kit setup (Windows, %PROCESSOR_ARCHITECTURE%)"
call :say "Lab kit folder: %KIT%"
if defined LITE call :say "Small kit (no Module 4 lab): using environment-lite.yml, without PyTorch."
if not exist "%ENV_FILE%" call :fail "environment.yml is missing. Unzip the whole lab kit, then run this file from its folder." & goto :end_fail

rem ---- fast path: everything is already set up -------------------------------------------------
call :find_conda
if not defined CONDA_BASE goto :step1
call "%CONDA_BASE%\condabin\conda.bat" activate %ENV_NAME% >>"%LOG%" 2>&1
if errorlevel 1 goto :step1
if not defined CONDA_PREFIX goto :step1
call :env_ok
if errorlevel 1 goto :step1_deactivate
if not exist "%CONDA_PREFIX%\ee105-arduino.ok" goto :step1_deactivate
call :say "[ok] Everything is set up (conda in %CONDA_BASE%, environment %ENV_NAME%)."
goto :start_jupyter

:step1_deactivate
call "%CONDA_BASE%\condabin\conda.bat" deactivate >>"%LOG%" 2>&1

rem ---- 1. conda ---------------------------------------------------------------------------------
:step1
if defined CONDA_BASE goto :step1_found
call :say "Step 1 of 4: installing Miniforge (conda) in %MINIFORGE_DIR% ..."
call :install_miniforge
if errorlevel 1 goto :end_fail
call :say "[ok] Step 1 of 4: installed Miniforge in %CONDA_BASE%"
goto :step2
:step1_found
call :say "[ok] Step 1 of 4: found conda in %CONDA_BASE%"

rem ---- 2. the ee105 environment -------------------------------------------------------------------
:step2
set "ENV_FAILED="
set "HAVE_ENV="
type nul > "%CONDA_OUT%"
call :online
if errorlevel 1 call :fail "No internet connection. Connect to the internet and try again." & goto :end_fail
call :check_space "%CONDA_BASE%" %ENV_GB%
if errorlevel 1 goto :end_fail
call "%CONDA_BASE%\condabin\conda.bat" activate %ENV_NAME% >>"%LOG%" 2>&1
if errorlevel 1 goto :step2_create
if not defined CONDA_PREFIX goto :step2_create
call :env_ok
if not errorlevel 1 set "HAVE_ENV=1"
call "%CONDA_BASE%\condabin\conda.bat" deactivate >>"%LOG%" 2>&1
if not defined HAVE_ENV goto :step2_update
call :say "     The environment %ENV_NAME% already has the packages; nothing to download."
goto :step2_activate
:step2_update
call :say "Step 2 of 4: updating the Python environment %ENV_NAME% (a few minutes) ..."
call "%CONDA_BASE%\condabin\conda.bat" env update -n %ENV_NAME% -f "%ENV_FILE%" %PRUNE% >"%CONDA_OUT%" 2>&1
if errorlevel 1 set "ENV_FAILED=1"
goto :step2_check
:step2_create
call :say "Step 2 of 4: creating the Python environment %ENV_NAME% (%ENV_NOTE%) ..."
call :say "     This window stays quiet until it is done; the details go to setup-log.txt."
call "%CONDA_BASE%\condabin\conda.bat" env create -n %ENV_NAME% -f "%ENV_FILE%" >"%CONDA_OUT%" 2>&1
if errorlevel 1 set "ENV_FAILED=1"
:step2_check
type "%CONDA_OUT%" >>"%LOG%" 2>nul
if not defined ENV_FAILED goto :step2_activate
rem Anaconda and Miniconda refuse to work until Anaconda's Terms of Service are accepted. The lab kit
rem takes all its packages from conda-forge, so it uses its own Miniforge instead of asking for that.
if defined TOS_RETRY goto :step2_failed
findstr /c:"CondaToS" "%CONDA_OUT%" >nul 2>&1
if errorlevel 1 goto :step2_failed
if /i "%CONDA_BASE%"=="%MINIFORGE_DIR%" goto :step2_failed
set "TOS_RETRY=1"
call :say "     The conda in %CONDA_BASE% (Anaconda or Miniconda) first wants Anaconda's Terms of"
call :say "     Service accepted. The lab kit does not need Anaconda's packages: it installs its own"
call :say "     Miniforge in %MINIFORGE_DIR% and uses that. Your other conda is not changed."
call :install_miniforge
if errorlevel 1 goto :end_fail
goto :step2
:step2_failed
call :check_space "%CONDA_BASE%" 1
if errorlevel 1 goto :end_fail
call :online
if errorlevel 1 call :fail "The internet connection dropped during the download. Try again." & goto :end_fail
call :fail "conda could not create the environment %ENV_NAME% (see the end of setup-log.txt)."
goto :end_fail
:step2_activate
call "%CONDA_BASE%\condabin\conda.bat" activate %ENV_NAME% >>"%LOG%" 2>&1
if errorlevel 1 call :fail "The environment %ENV_NAME% was created but cannot be activated." & goto :end_fail
rem record which file the environment matches; an environment kept as it was keeps its own record
if not defined HAVE_ENV copy /y "%ENV_FILE%" "%CONDA_PREFIX%\ee105-environment.yml" >nul
call :say "[ok] Step 2 of 4: Python environment %ENV_NAME% in %CONDA_PREFIX%"

rem ---- 3. Arduino tools ---------------------------------------------------------------------------
call :say "Step 3 of 4: installing the Arduino tools and the Nano 33 BLE board package (5 to 10 minutes) ..."
call :say "     Windows may ask to install the Arduino USB driver: click Install."
python -m ee105 setup >>"%LOG%" 2>&1
if errorlevel 1 goto :step3_failed
type nul > "%CONDA_PREFIX%\ee105-arduino.ok"
call :say "[ok] Step 3 of 4: Arduino tools installed"
goto :step4
:step3_failed
call :say "[!!] Step 3 of 4: the Arduino tools did not install (see setup-log.txt). The first lab"
call :say "     notebook that uses the board tries again, or run this file again later."

rem ---- 4. JupyterLab ------------------------------------------------------------------------------
:step4
call :say "[ok] Step 4 of 4: setup complete."

:start_jupyter
call :say ""
call :say "Starting JupyterLab in your web browser. Keep this window open while you work;"
call :say "close the browser tab and this window when you are done."
cd /d "%KIT%"
jupyter lab
if errorlevel 1 call :fail "JupyterLab did not start (see setup-log.txt)." & goto :end_fail
endlocal
exit /b 0

:end_fail
echo.
pause
endlocal
exit /b 1

rem ================================================================== subroutines
:install_miniforge
rem installs Miniforge in %MINIFORGE_DIR% and sets CONDA_BASE to it; errorlevel 1 (after :fail) if it cannot
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" call :say "     This is an ARM64 computer: Miniforge runs in x64 emulation (Windows 11 needed)."
call :online
if errorlevel 1 call :fail "No internet connection. Connect to the internet (USC Secure Wireless or eduroam work) and try again." & exit /b 1
call :check_space "%USERPROFILE%" %NEED_GB%
if errorlevel 1 exit /b 1
set "INSTALLER=%TEMP%\Miniforge3-Windows-x86_64.exe"
call :say "     downloading Miniforge3-Windows-x86_64.exe ..."
del "%INSTALLER%" >nul 2>&1
curl.exe -fL --retry 3 -o "%INSTALLER%" "%MINIFORGE_URL%" >>"%LOG%" 2>&1
if errorlevel 1 del "%INSTALLER%" >nul 2>&1 & powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri '%MINIFORGE_URL%' -OutFile $env:INSTALLER" >>"%LOG%" 2>&1
if not exist "%INSTALLER%" call :fail "Could not download Miniforge. Check the internet connection and try again." & exit /b 1
call :say "     installing (2 to 5 minutes) ..."
start "" /wait "%INSTALLER%" /InstallationType=JustMe /RegisterPython=0 /AddToPath=0 /S /D=%MINIFORGE_DIR%
del "%INSTALLER%" >nul 2>&1
if not exist "%MINIFORGE_DIR%\condabin\conda.bat" call :fail "The Miniforge installer did not finish. Check that the disk has space, then try again." & exit /b 1
set "CONDA_BASE=%MINIFORGE_DIR%"
exit /b 0

:env_ok
rem errorlevel 0 if the active environment has what this kit needs
fc /b "%ENV_FILE%" "%CONDA_PREFIX%\ee105-environment.yml" >nul 2>&1
if not errorlevel 1 exit /b 0
if not defined LITE exit /b 1
rem small kit: an environment made earlier (for example by the full kit) is fine if it has the packages
python -c "import numpy, pandas, matplotlib, scipy, sympy, serial, jupyterlab" >>"%LOG%" 2>&1
if errorlevel 1 exit /b 1
exit /b 0

:say
echo(%~1
>>"%LOG%" echo(%DATE% %TIME%  %~1
exit /b 0

:fail
call :say ""
call :say "SETUP STOPPED: %~1"
call :say "Details are in setup-log.txt in the lab kit folder. Fix the problem, then double-click"
call :say "setup-windows.bat again; finished steps are not repeated."
exit /b 1

:find_conda
set "CONDA_BASE="
for %%D in ("%MINIFORGE_DIR%" "%USERPROFILE%\miniforge3" "%USERPROFILE%\mambaforge" "%USERPROFILE%\miniconda3" "%USERPROFILE%\anaconda3" "%LOCALAPPDATA%\miniforge3" "%LOCALAPPDATA%\miniconda3" "%LOCALAPPDATA%\anaconda3" "%LOCALAPPDATA%\Programs\miniforge3" "%LOCALAPPDATA%\Programs\miniconda3" "%LOCALAPPDATA%\Programs\anaconda3" "%ProgramData%\miniforge3" "%ProgramData%\miniconda3" "%ProgramData%\anaconda3" "%SystemDrive%\miniforge3-ee105" "%SystemDrive%\miniforge3" "%SystemDrive%\miniconda3" "%SystemDrive%\anaconda3") do if not defined CONDA_BASE if exist "%%~D\condabin\conda.bat" set "CONDA_BASE=%%~D"
if defined CONDA_BASE exit /b 0
for /f "delims=" %%C in ('where conda.bat 2^>nul') do if not defined CONDA_BASE for %%P in ("%%~dpC..") do if exist "%%~fP\condabin\conda.bat" set "CONDA_BASE=%%~fP"
exit /b 0

:online
curl.exe -s -o nul -I --max-time 20 https://conda.anaconda.org/conda-forge/ >nul 2>&1
if not errorlevel 1 exit /b 0
curl.exe -s -o nul -I --max-time 20 https://github.com/ >nul 2>&1
if not errorlevel 1 exit /b 0
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -Method Head -TimeoutSec 20 -Uri https://github.com/ | Out-Null; exit 0 } catch { exit 1 }" >nul 2>&1
if not errorlevel 1 exit /b 0
exit /b 1

:check_space
rem %1 = a folder on the disk to check, %2 = GB needed
set "FREE_GB="
set "CHECK_DIR=%~1"
for /f "delims=" %%G in ('powershell -NoProfile -Command "[int][math]::Floor((Get-Item -LiteralPath $env:CHECK_DIR).PSDrive.Free / 1GB)" 2^>nul') do set "FREE_GB=%%G"
if not defined FREE_GB exit /b 0
if %FREE_GB% GEQ %~2 exit /b 0
if "%~2"=="1" call :fail "The disk is full. Free some space and try again." & exit /b 1
call :fail "Only %FREE_GB% GB free on the disk; the lab kit needs about %~2 GB. Free some space and try again."
exit /b 1
