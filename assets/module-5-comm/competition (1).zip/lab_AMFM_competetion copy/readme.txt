In this competition, your task is to transmit a message from one development board to another. 
You are free to use any modulation technique to achieve this.

The folder structure is as follows:
    - The folder /devboard_sketch_receiver contains the Arduino code for the receiver.
    - The folder /devboard_sketch_sender contains the Arduino code for the sender.

There are two Python notebooks provided:
    - sender.ipynb is used to communicate with the sender Arduino.
    - receiver.ipynb is used to communicate with the receiver Arduino.

At the end of each notebook, you will find comments indicating where to add your modulation code and make the necessary changes.

Good luck!
