"""
EE105 lab check-in
==================
Students: you don't need to read or edit this file.

Load it in a notebook with
    %run ee105_checkin.py lab1.2
then run the register cell:
    register(name="Your Name", email="yourid@usc.edu")

How the checkpoints work
- Every checkpoint question tells you whether your answer is correct. If it
  isn't, try again until it is. Each question is worth one point; the TA
  tallies points after the lab.
- Equation and solution checks: run the test cell after your code, e.g.
  test_kcl(kcl_equations). You are told pass or not-yet, and nothing more -
  finding the mistake is the exercise. If your code crashes you'll see the error.
- Question 3.1 takes a number rounded to 2 decimal places, or simply the SymPy
  value from your solution, e.g. quiz("3.1", solution_substituted[s2]).

What gets sent to the TA: your name, email, section, which checkpoint you worked
on, your running score for it, and the time - nothing else. No internet?
Everything still works locally and your saved notebook covers your work.
"""

import contextlib
import hashlib
from fractions import Fraction
import io
import json
import sys
import threading
import time
import urllib.parse
import urllib.request

# ---------------- TA CONFIGURATION (see ta-tools/README.md) ----------------
# One entry per lab: which Google Form (and therefore which "Form Responses N"
# tab) this lab's check-ins go to. The notebook's %run argument picks the entry:
#     %run ee105_checkin.py lab1.2    ->  LAB_FORMS["lab1.2"]
#
# Adding a lab: make its form, then run
#     python3 ta-tools/extract_entry_ids.py "<pre-filled URL>" --lab lab3
# and paste the printed block below. Leave older labs in place — unused entries
# cost nothing, and keeping them means an old notebook keeps working.
LAB_FORMS = {
    # "lab2": {   # EE105 Lab 2 Progress  ->  sheet tab "Form Responses 1"
    #     "form_url": "https://docs.google.com/forms/d/e/1FAIpQLSdA222BHCDShshEsOviOHWNxREyoc1yMu-i5yJ5cFTWrEvZWg/formResponse",
    #     "name":     "entry.539499380",
    #     "email":    "entry.1164992321",
    #     "item":     "entry.167614228",
    #     "status":   "entry.2119807945",
    #     "detail":   "entry.1976500257",
    #     "section":  "entry.724940179",
    # },
    "lab2": {
        "form_url": "https://docs.google.com/forms/d/e/1FAIpQLSeuBA8uuSpZqOktXq_vwPOEx4PUS83zwc3JjKUYxxaXYLtlOA/formResponse",
        "name":     "entry.539499380",
        "email":    "entry.1164992321",
        "item":     "entry.167614228",
        "status":   "entry.2119807945",
        "detail":   "entry.1976500257",
        "section":  "entry.724940179",
    },
    # TODO (TA, before shipping): make the Lab 1.2 progress form (ta-tools/HOWTO-new-lab-form.md),
    # run   python3 ta-tools/extract_entry_ids.py "<pre-filled URL>" --lab lab1.2 --test
    # and paste the block it prints here. Until then the notebook still works; it just
    # tells students their work is saved locally and nothing reaches the sheet.
    "lab1.2": { # EE105 Lab 1.2 Circuit Analysis with Python
        "form_url": "https://docs.google.com/forms/d/e/1FAIpQLSdsUDBrack0b6omT_zy5ot_io4NYejMIKxlget_pzl8qgB2Wg/formResponse",
        "name":     "entry.539499380",
        "email":    "entry.1164992321",
        "item":     "entry.167614228",
        "status":   "entry.2119807945",
        "detail":   "entry.1976500257",
        "section":  "entry.724940179"
    }
}
DEFAULT_LAB = "lab1.2"                     # used if the %run argument is missing
_LAB_ALIASES = {"tutorial": "lab2", "questions": "lab2"}   # older notebooks
COURSE_SALT  = "EE105-F26"
REQUIRE_ROSTER = False   # True = students not on the roster below cannot register

# Credit for a short-answer question, by the attempt on which it is FIRST
# answered correctly: try 1 = 1.0, try 2 = 0.75, try 3 = 0.5, any later try = 0
# (course policy, 2026-09-19). Edit the list to change the ladder.
# Students are never shown this — they only see correct / try again.
ATTEMPT_CREDIT = [1.0, 0.75, 0.5]
# The equation / solution checks (the test_... cells) keep full credit whenever they
# eventually pass — debugging is the exercise. Set True to apply the same ladder to them too.
# (A crash is never counted as an attempt.)
CODING_CREDIT_DECAYS = False

# Class roster: sha256 digest of each enrolled email -> section number (the
# roster itself is not readable from this file). Generate with:
#   python3 ta-tools/make_roster.py <roster1.csv> <roster2.csv>
_ROSTER_SECTIONS = {
    "014beb7d951c529882c0708e5cfbde0535850dd8448950de901db884ab00ea49": "30884",
    "03579d0690d6275a87a1b6e7882283d3f54a39276a0b1310033c19030673720a": "30882",
    "070b16ab77f0185fe05befd0984393236647eaad42c7f31c8961f1eaead95433": "30882",
    "0d362ae000f93c57b52def0ad6f0e45c829b803dbc8dc511507a57d1e2a47494": "30884",
    "0d7ed666367a74908999a4ba267dbcc245efa64f49192ddd2814c85f49fc3baf": "30882",
    "0f4be59a94b618737833e34f388a74de2f7640f728993b1f6327061e147e7e39": "30882",
    "0f74e5e9f349b396af4670fa55fbb61256f11dc5f3e653347406eab357d36219": "30882",
    "10a53d8054c8c7c7e148b01861638bad30093ea4176c61fb4b2f6f59b3eb7925": "30884",
    "112ee8c7d094c78cd79011b6fd53a13cbcd9cbc12083451c86999825fc731814": "30884",
    "165fa85e71cf51df649f74a383ab339fc31a426cec55e48f7887dfe8f69d0ad6": "30882",
    "1799542860d70dd4d644c6e9e5886b36bb8af788869cf2872c4f68bd825af107": "30884",
    "17e252bfc06c62aa03a5600fd9e7c771cc803068176f15737eb1649512a78a85": "30884",
    "17f79d6f28ffd1f09569798d6fab1cf4354bc4eaee5b98c35200454c9fd2397e": "30882",
    "198fb53313c3cde24f0d477cdf673371178b3156169d0c179c17669aaeef89e1": "30884",
    "1c31e616312e873f440d896ac50cf6eb03daec8a8855ad33a912390b48c3f58a": "30884",
    "25597d458ea4feb7b80f28264b76e420a7580252b4d41681a2c44cb2075646a4": "30882",
    "258b6b69b8bc0b1ea3d4a16021783aae13ab21b435178dc918b4b57dceb143f4": "30884",
    "26518d5ea856d975eb04389ad8b0acf2fa0ff9593750b03f65ce9c9c3be3acb6": "30884",
    "2b6b5f669c34ac1c24701e9a71c0a3ad257dea8f3ae2b25e0bb9af85c72ba068": "30884",
    "311195f20d6392675ad23e767de84296ee0a267dc04f4218901d1ae673c294f5": "30882",
    "333ca83df103a50a3f3c1ef36454850d854594731b94c0c81b46a2361741fa20": "30882",
    "36d9788a5b14c6f5e5c3f71cbc7baeeaa5e52723360333c73da640445306a7ce": "30882",
    "382df582a6823972c06d3373457f9ca5aade13c367dbd70fd168ddf89c3852bb": "30882",
    "3adf0eae09967d6428801529f091209fb4a9be1be44a2f1af7bcca8ae3660ef0": "30882",
    "3e67b0c2520c33be5cec3c048e1e9408c8d6eb46be5c47f9629d8fce5181c0d5": "30882",
    "3fc32236914cd15ad88f1e601320f58fceddaa0eb510e0df90822c9ed5dda5cd": "30882",
    "405ef74e5c4145ddfea1dc7f040c9ca277529f98a2a0072dc5db3b7e43df0144": "30884",
    "4148be4070702d98e25a5cb010b9d6cb3beda1add5d9c15dc92bb480da478503": "30884",
    "45b40d09ff552c2b573fc0f18d2541529c5f27b1793855e69e2692499aba63c8": "30884",
    "48ec00a39e87e40a25a01ddcc66b38df87f50cafdf00a49b94d7ddbfb368e33b": "30884",
    "52a23545e7f53fd8b0b2cb12a30f7945f662f6baa76cfce9846664a08ed69884": "30882",
    "53c3102b8880c8640bd98fa4dd6d9917c82ba476807c458a56fdb0e91823e05a": "30884",
    "5647dc3c6ccbe30d844fe9fbe7eee6107b35863e1c869afbf47a58ffac8d8936": "30882",
    "5994afcd1841a7199e57e946a01a65152680dc527ed77dd0a607686262666159": "30884",
    "59d631510ee652962d47a60253fe9ca961c126bed76075272683c75045200620": "30884",
    "5c4dcdc80e41417d024c030b02f0bf35e002e7dd3859ada1919f30dbd8534ef8": "30882",
    "5c7ad03c71e4a34caaa1ade3d19182c76c03a09dc174b582988cee68d5742437": "30884",
    "5de42582f8a20a2adaa9108962e509b2f5478f771f5932820d36aa07447b489c": "30884",
    "607b68d3ae7a99aa8ca4dba139a125804ea9638c8b69850ea48a81b9b74db2aa": "30884",
    "664d70568f095327bf16e6376a15988751272448ef14dcdf8e06aceffd9ebbfb": "30884",
    "6ba786c7924ef6ad606b5e4e80a80be6827279645acc4f2cd3572f20dafcaaad": "30882",
    "6d45036799e6910fff89c8443cebd33083154060fc5e4c3d39d9884d4a392fdd": "30884",
    "6dabc538e54c9f120aa08735e05c639498b6e1548c619b069996803a376059d5": "30884",
    "6fec52a3bd11f5a488bc224eb759d786de88f568c6a7864b761f2dfef8587eda": "30882",
    "70ec934570bf6edf38b9622fe83897f41e964d9741264e02eb3a17ba31a9f377": "30882",
    "7148fe043cc0bf1d39ff2dd48e02683c157dc4271ceadd9ce4edaebbfef1cabb": "30882",
    "724a962f6ea9947d1f92ac2d93a29013072814937934c30d2265e048c5b6c773": "30884",
    "76a6c8cf1864737fefccc2be302af54747e1f285c7c70e94d420ff056caede84": "30884",
    "77d4ed8b38da80b117c3e2d3c29aab9b6decf3ca344b8474e8098eed198870b5": "30882",
    "7877bccaf9a1866e9bdbe932815d750ac14341ad1579a5d687c8b443dad1fb4f": "30882",
    "794220004f7a1013e8c1757940718a2947f25a9fcc2fa38e9846a074e82a760c": "30882",
    "7baae787e8d1b958fb0e673d9a7af512d7e7038aad14932296a77d0e4ceb5886": "30882",
    "7ce5a2a36f811be04e91f73847f5ad0d93dc5434ef5be2db7bf223b823e099b6": "30882",
    "7da7c2354c53726f72bf8c292f72252cc73e93877620cfbf0807be2a528e9558": "30882",
    "7fbbf08b33b21a96f42dd38912df3f4fb02ca2413ca77ee3e85a61018dab1e54": "30884",
    "8036c2a065b4742c372ce88a9420a25856838414b7d1d4701490f377743bd720": "30884",
    "8459abe6610221e5cf1c9b9649e276225582a1c8c7302e30f4a09b36605ba305": "30882",
    "870ce15861ad6b4a2d2e55bc91f1fd155846bef5488673ef2eecfa633e70c21f": "30884",
    "8b30739adec79428584e0d60bf61e5d3ed6999918c11f3e41b437d2c106ab456": "30884",
    "8e204ef3e0c8659f2550bec719bfe0e8141aa1003744360497ebb4d87aafb354": "30884",
    "91cd001da0e1b2107ae1517e81cf5829ed24124c1a9153bb67707ff5a1cee4cc": "30884",
    "9af0ce5d7709710f3888f1c138f1571f7b22d3eb0936ada608fa33c3d17924f1": "30884",
    "9c662645c92c63696efc8916b600b28de5fb83478912dab3fbf34840c8572b3d": "30884",
    "a3ef83553bff485466ea29ab3bac090cdcc7ef2d5f7e157aeb1a52aadc3745a9": "30882",
    "ac2e67d2bd3b99cc24e6e9ec0f708bf71a97b6cae1b1d7ccb9ce96bac82fa224": "30882",
    "ad03af0554ffa7ebba04e721b5a28376b7833e92a25aa23257c564ef10860b29": "30882",
    "ba40c927c1fe49059e939fe376ab809a5cb0d7237c9320bc805ff73f0995109f": "30884",
    "bb2e88b76ad6c6cdb2516f59f2f79c26c77c963bab09d271963c30a9d5cea187": "30884",
    "bc899dffa871be649e6b33cc9e20a66f3475d0ced85867821fab6e636fc8b109": "30882",
    "bcbe2c8e60a97c29be9a01235cc6c2dbba10b283fe010deeb8fe6370f3a3f127": "30882",
    "bd09e61da5c4b0dd5885e0c44f39a95264aa2620ec40c64d771155aa503bc37a": "30882",
    "bf2bb42bd71c785704bf13c75a99dc3092609992f67cd87beb0ea3594e9ac481": "30884",
    "c25aa5aa3cc6ba690ee7089aadcc5c2f7b2a8d6df86f32cd539dd554e2546aa7": "30884",
    "c6a903d79d2991051b4e62c98267e8438667cf944e44f64d64fe92388ed53ee5": "30884",
    "c718797e569125fb9c7854b1caff6d13a808febed2443c4b9ebbe4fe7d314b1c": "30882",
    "cf2e4478f93ec28fec7a57aa44adceb2c17cd7804e5c4ec9868d5e4435dad8be": "30882",
    "cfef0af0502d0359a98ce25ac0cad1d310176c07179bf3bc5f1f4697c921b727": "30884",
    "d0c8160ed7713f80078f7b787c68ef0ab751833414a31a625bf2923994006527": "30882",
    "d4db54fb31ce38e6018566912e5be81777858ccf9dc8008cab3639fb32092ecd": "30884",
    "d55905e2e3870abb2bf5f31d7b4d41cd3fcc88007199651de4bd7cebd3c69f5a": "30884",
    "d7ea20165a56f4adbcee0ceaf3147aa829a9b27c17c66060fa7cd25c3fa19860": "30882",
    "dc3006d3ce06ddbd146d220841f378e491c57941a7c9f4d564a028a0008b0246": "30882",
    "dc587c37bbd36c78b19d8012b7631d0039414709bdd4b07bec09e95a7e48737c": "30884",
    "de50976c8f864d24ad52c8b7f6a9db23b93709a60f773d8f287d316bb89f925f": "30882",
    "e2a81778a68c77c9dd605cc851495323bbf725a79428c77850cd14f4a6067c8a": "30882",
    "e467efda363d10e374266e67fc640bb6dc4983e6db1a7847a41e7b9caa6609c7": "30884",
    "e80de245c8ad027390c35aeea8e4a3ad393f9973f022b0bdee18ad5ca31b80a3": "30884",
    "e9f49dbeffb908afc08818c87b53e7c95f0d877db3248be258aa0621e12ebc6e": "30882",
    "ecd67f1d287e7256ae48fde252fa83e42f2db832eb3c96d3d8c6693d4efaccb3": "30884",
    "ee4741cc733590b4b16ec828c7fd0fc8aae2f5d55bfb4b1481ba3099cb29c703": "30884",
    "ee514994a8cab9315c2c9268c8fe6474b9ec0b668b10ae9fac6ed09c9f751d71": "30882",
    "f21753c1bbf227c155f4262f25aba3b46c607a178f440710d9ac08e3887f58a4": "30884",
    "f399dd064035f2f0fea5ab15d34be94dbf690f49142a0ab50cd2035788cdd25a": "30882",
    "f402f40194c1589ca6d234c4d0afafcbf866a5e9f0d88a9c2c9e9ea544256d04": "30884",
    "f43be37ef2dc9fda68af4a1889ecee6b6282d2cb236860e1da86d7eb9e5051fa": "30882",
    "f5f11650b30b3edb96d0f16d8dbfad33201f131e2d4a013c9346c9599cc8e177": "30884",
    "fa298ac14cefc30a2f0960e31809da89a5f2aa1ed62bc4eb8534a7aa7cc52480": "30882",
    "fc2513e9fbed37d608eb086807fa876dd3f36133f1ab8f5d430fe1023c044561": "30884",
}
# ---------------------------------------------------------------------------

# Checkpoint structure. Each question is worth one point.
_CHECKPOINTS = {
    "1": {"title": "KCL equations",          "items": ["1.1"]},
    "2": {"title": "Ohm's-law equations",    "items": ["2.1"]},
    "3": {"title": "Solve with SymPy",       "items": ["3.1"]},
    "4": {"title": "Networks 1 and 2",       "items": ["4.1", "4.2", "4.3", "4.4"]},
}

# Short-answer questions: sha256("q<item>|<normalized answer>").
# 3.1 is numeric (see _QUIZ_ROUND): the list holds the rounded answer and its two
# neighbours in the last decimal place, so rounding vs. truncation both pass.
# Regenerate with:  python lab12_solutions.py --digests   (TA-only file)
_QUIZ_DIGESTS = {
    "3.1": ['b9f7abc8db6c4dab5a65300c240d5113d5019978601de0f761fcd1cbac0511fd',
            'df4994a58f389428dcaf0425a6d891fec941448c7bceb653b8f1709a7b8d9861',
            '566fc92d6c39c32d5dbb00ef745ff3b0dc8c60497f21904b3767e2f28f0e410d'],
}

# Numeric questions checked to a fixed number of decimals: the answer (a float,
# a SymPy value, or text like "1.23" / "33/20") is rounded to this many
# places before hashing. Items not listed keep the exact-match rule above.
_QUIZ_ROUND = {"3.1": 2}

# Autograder test function -> checkpoint item
_TEST_ITEMS = {
    "test_kcl": "1.1",
    "test_ohm": "2.1",
    "test_network1_voltages": "4.1",
    "test_network1_currents": "4.2",
    "test_network2_voltages": "4.3",
    "test_network2_currents": "4.4",
}
_CODING_ITEMS = set(_TEST_ITEMS.values())
_CREDIT_VALUES = sorted({0.0, *ATTEMPT_CREDIT})

_PROGRESS_FILE = ".ee105_progress.json"
_arg = sys.argv[1].strip().lower() if len(sys.argv) > 1 else ""
_LAB = _LAB_ALIASES.get(_arg, _arg) or DEFAULT_LAB
_NOTEBOOK = _LAB                       # item prefix in the sheet, e.g. "lab2:cp1"

_form = LAB_FORMS.get(_LAB, {})
FORM_URL      = _form.get("form_url", "")
ENTRY_NAME    = _form.get("name", "")
ENTRY_EMAIL   = _form.get("email", "")
ENTRY_ITEM    = _form.get("item", "")
ENTRY_STATUS  = _form.get("status", "")
ENTRY_DETAIL  = _form.get("detail", "")
ENTRY_SECTION = _form.get("section", "")
if _arg and _LAB not in LAB_FORMS:
    print(f"⚠️  No form configured for lab {_LAB!r} — your work is saved on this "
          f"computer, in this notebook.")

_student = {"name": "", "email": "", "section": ""}
_state = {"answered": {}, "tok": {}, "_sent": {}, "_reported": {}}
_failed_reports = [0]
_file_lock = threading.Lock()

try:
    _ns = get_ipython().user_ns  # noqa: F821  (defined when running under IPython)
except NameError:
    _ns = globals()

_configured = bool(FORM_URL and ENTRY_NAME and ENTRY_EMAIL
                   and ENTRY_ITEM and ENTRY_STATUS)


# ------------------------------ scoring ------------------------------------
# Each answered question holds an opaque token encoding either "wrong" or
# "ok:<credit>", so correctness and credit aren't readable at a glance.

def _cp_of(item):
    return item.split(".")[0]


def _fmt(x):
    return f"{x:g}"


def _tok(item, tag, email=None):
    e = _student["email"] if email is None else email
    return hashlib.sha256(f"{e}|{item}|{tag}|{COURSE_SALT}".encode()).hexdigest()[:16]


def _tag_of(token, item, email=None):
    """Decode a token -> "wrong", "ok:<credit>", or None if unrecognized."""
    if token is None:
        return None
    if token == _tok(item, "wrong", email):
        return "wrong"
    for v in _CREDIT_VALUES:
        tag = f"ok:{_fmt(v)}"
        if token == _tok(item, tag, email):
            return tag
    return None


def _is_answered(item):
    return item in _state["answered"]


def _is_correct(item):
    tag = _tag_of(_state["tok"].get(item), item)
    return bool(tag) and tag.startswith("ok:")


def _credit(item):
    tag = _tag_of(_state["tok"].get(item), item)
    return float(tag[3:]) if tag and tag.startswith("ok:") else 0.0


def _score(cp):
    return sum(_credit(i) for i in _CHECKPOINTS[cp]["items"])


def _credit_for(item, attempt):
    if item in _CODING_ITEMS and not CODING_CREDIT_DECAYS:
        return 1.0
    return ATTEMPT_CREDIT[attempt - 1] if attempt - 1 < len(ATTEMPT_CREDIT) else 0.0


def _record(item, correct):
    """Record a real attempt; returns the attempt number. No-op once correct."""
    if _is_correct(item):
        return _state["answered"][item]["attempts"]
    a = _state["answered"].setdefault(item, {"attempts": 0, "last": ""})
    a["attempts"] += 1
    a["last"] = time.strftime("%Y-%m-%d %H:%M:%S")
    tag = f"ok:{_fmt(_credit_for(item, a['attempts']))}" if correct else "wrong"
    _state["tok"][item] = _tok(item, tag)
    _save()
    return a["attempts"]


# ---------------------------- persistence ----------------------------------

def _load_file():
    try:
        with open(_PROGRESS_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def _save():
    if not _student["email"]:
        return
    try:
        with _file_lock:
            data = _load_file()
            data[_student["email"]] = {k: v for k, v in _state.items()}
            with open(_PROGRESS_FILE, "w") as f:
                json.dump(data, f, indent=1)
    except Exception:
        pass


def _restore(email):
    """On registration: re-key in-memory work to this email and merge saved progress."""
    old = _student["email"]
    for item, t in list(_state["tok"].items()):
        _state["tok"][item] = _tok(item, _tag_of(t, item, old) or "wrong", email)
    rec = _load_file().get(email) or {}
    for item, a in rec.get("answered", {}).items():
        cur = _state["answered"].get(item)
        if cur is None or a.get("attempts", 0) > cur.get("attempts", 0):
            _state["answered"][item] = a
    for item, t in rec.get("tok", {}).items():
        saved = _tag_of(t, item, email) or "wrong"
        cur = _tag_of(_state["tok"].get(item), item, email)
        if cur is None or (saved.startswith("ok:") and not cur.startswith("ok:")):
            _state["tok"][item] = _tok(item, saved, email)
    _state["_sent"] = rec.get("_sent", {})
    _state["_reported"] = rec.get("_reported", {})


# ----------------------------- reporting -----------------------------------

def _report(item, status, detail="", on_success=None):
    if not (_configured and _student["email"]):
        return

    def _post():
        try:
            fields = {
                ENTRY_NAME:   _student["name"],
                ENTRY_EMAIL:  _student["email"],
                ENTRY_ITEM:   item,
                ENTRY_STATUS: status,
                ENTRY_DETAIL: detail,
                "fvv": "1", "pageHistory": "0",
            }
            if ENTRY_SECTION:
                fields[ENTRY_SECTION] = _student.get("section", "")
            payload = urllib.parse.urlencode(fields).encode()
            url = FORM_URL.replace("/viewform", "/formResponse")
            req = urllib.request.Request(url, data=payload, headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": "ee105-checkin",
            })
            urllib.request.urlopen(req, timeout=5)
            if on_success:
                on_success()
        except Exception:
            _failed_reports[0] += 1

    threading.Thread(target=_post, daemon=True).start()


def _report_once(key, item, status, detail=""):
    """Send an event at most once per student, ever (e.g. registration)."""
    if not (_configured and _student["email"]) or key in _state["_reported"]:
        return False

    def ok():
        _state["_reported"][key] = time.strftime("%Y-%m-%d %H:%M:%S")
        _save()
    _report(item, status, detail, ok)
    return True


def _report_checkpoint(cp, item=None):
    """Send the checkpoint's running score (may be fractional). Sent on a
    question's first attempt and whenever the score changes, so the sheet
    always holds the latest score (use MAX per student x checkpoint)."""
    if not (_configured and _student["email"]):
        return
    items = _CHECKPOINTS[cp]["items"]
    answered = [i for i in items if _is_answered(i)]
    if not answered:
        return
    score = _score(cp)
    first = item is not None and _state["answered"][item]["attempts"] == 1
    if not (first or _state["_sent"].get(cp) != score):
        return
    marks = " ".join(f"{i}:{_fmt(_credit(i)) if _is_correct(i) else 'x'}" for i in answered)
    detail = (f"{item} attempt {_state['answered'][item]['attempts']}; " if item else "") \
        + f"answered {len(answered)}/{len(items)}; {marks}"

    def ok():
        _state["_sent"][cp] = score
        _save()
    _report(f"{_NOTEBOOK}:cp{cp}", _fmt(score), detail, ok)


# ----------------------------- student API ---------------------------------

def register(name="", email=""):
    """Register yourself for this lab session. Edit name and email, then run."""
    name = str(name).strip()
    email = str(email).strip().lower()
    if not name or name.lower() in ("your name", ""):
        print("❌ Please put your real name in the register cell, then run it again.")
        return
    if ("@" not in email or "." not in email.split("@")[-1] or " " in email
            or email.startswith("yourid@")):
        print("❌ Please put your real USC email in the register cell, then run it again.")
        return

    on_roster, section = True, ""
    if _ROSTER_SECTIONS:
        digest = hashlib.sha256(f"roster|{email}".encode()).hexdigest()
        section = _ROSTER_SECTIONS.get(digest, "")
        on_roster = bool(section)
        if not on_roster:
            section = "unknown"
            if REQUIRE_ROSTER:
                print(f"❌ {email} isn't on the class roster.")
                print("   Check the spelling of your email; if you recently joined the class,")
                print("   ask your TA to add you to the roster.")
                return
            print(f"⚠️  {email} isn't on the class roster — check the spelling!")
            print("   (If you recently joined the class, tell your TA.)")

    _restore(email)
    _student["name"], _student["email"], _student["section"] = name, email, section

    restored = len(_state["answered"])
    print(f"✅ Registered: {name} <{email}>"
          + (f" — Section {section}" if on_roster and section else "")
          + (" ✔ roster verified" if _ROSTER_SECTIONS and on_roster else ""))
    if not email.endswith("usc.edu"):
        print("   (Heads up: that doesn't look like a USC email — make sure it's the one the TA knows.)")
    if restored:
        print(f"   {restored} previously answered question(s) restored.")
    _save()

    detail = f"notebook={_NOTEBOOK}"
    if _ROSTER_SECTIONS:
        detail += f", roster={'ok' if on_roster else 'NOT-FOUND'}"
    if _configured:
        if _report_once("register", "register", "ok", detail):
            print("   Your check-ins will appear on the TA's class-progress sheet.")
        else:
            print("   Already checked in with the TA earlier — no duplicate row sent.")
        for cp in _CHECKPOINTS:          # catch up on offline / pre-registration work
            _report_checkpoint(cp)
    else:
        print("   Live reporting is not configured — results will be kept on this computer only.")


def _as_number(answer):
    """float() for anything numeric: int/float, NumPy scalars, SymPy values, and
    strings like "-4.71" or "-1240/263". Raises ValueError for anything else."""
    try:
        return float(answer)
    except (TypeError, ValueError):
        pass
    text = str(answer).strip().strip("'\"")
    try:
        return float(text)
    except ValueError:
        return float(Fraction(text))


def _canon(value, ndigits):
    """Canonical text for a number rounded to ndigits decimals ("-0.00" -> "0.00")."""
    text = f"{round(value, ndigits):.{ndigits}f}"
    if text.startswith("-") and float(text) == 0:
        text = text[1:]
    return text


def quiz(item, answer=...):
    """Check your answer to checkpoint question <item>, e.g. quiz("2.1", 42)."""
    item = str(item).strip()
    cp = _cp_of(item)
    if cp not in _CHECKPOINTS or item not in _QUIZ_DIGESTS:
        print(f"❌ There is no short-answer question {item!r}. Use the form  quiz(\"2.1\", answer)")
        return
    if answer is ... or str(answer).strip() in ("", "..."):
        print(f"✏️  Replace ... with your answer to {item}, then run the cell again.")
        return
    if not _student["email"]:
        print("⚠️  You're not registered yet — run the register cell first so this counts!")
    if _is_correct(item):
        print(f"✅ {item} is already answered correctly.")
        return

    if item in _QUIZ_ROUND:                       # numeric question, fixed decimals
        try:
            norm = _canon(_as_number(answer), _QUIZ_ROUND[item])
        except (ValueError, TypeError, ZeroDivisionError, OverflowError):
            print(f"❌ {item} needs a number — e.g. quiz(\"{item}\", 1.23).")
            return
    else:                                         # exact match: numbers via %g, else text
        try:
            norm = "%g" % _as_number(answer)
        except (ValueError, TypeError, ZeroDivisionError, OverflowError):
            norm = str(answer).strip().lower().strip("'\"")
    accepted = _QUIZ_DIGESTS[item]
    if isinstance(accepted, str):
        accepted = [accepted]
    correct = hashlib.sha256(f"q{item}|{norm}".encode()).hexdigest() in accepted
    _record(item, correct)
    if correct:
        print(f"✅ Correct!")
    else:
        print(f"❌ Incorrect — please try again.")
    _report_checkpoint(cp, item)


def connect_tests():
    """Wrap the autograder so coding answers are checked and recorded with the TA."""
    wrapped_count = 0
    for name, item in _TEST_ITEMS.items():
        fn = _ns.get(name)
        if not callable(fn) or getattr(fn, "_ee105", False):
            continue
        _ns[name] = _make_wrapper(name, fn, item)
        wrapped_count += 1
    if wrapped_count:
        print("🔗 Autograder connected — running a test cell checks and records your answer.")


def _make_wrapper(name, fn, item):
    cp = _cp_of(item)

    def wrapped(*args, **kwargs):
        if not _student["email"]:
            print("⚠️  You're not registered yet — run the register cell first so this counts!")
        if _is_correct(item):
            print(f"✅ Question {item} already passed.")
            return
        sink = io.StringIO()
        try:
            with contextlib.redirect_stdout(sink):
                fn(*args, **kwargs)
            correct = True
        except AssertionError:
            # Course policy (2026-09-20): students are told pass / not-yet and nothing more.
            # To explain failures again, capture str(e) here and print it in the else branch below.
            correct = False
        except Exception as e:
            print(f"⚠️  Your code raised {type(e).__name__}: {str(e)[:120]}")
            print("   Fix it and run this cell again.")
            return                                   # a crash is not an attempt
        _record(item, correct)
        if correct:
            print(f"✅ Correct — question {item} passed!")
        else:
            print(f"❌ Not yet — question {item} failed the check. Fix your code and run again.")
        _report_checkpoint(cp, item)

    wrapped._ee105 = True
    wrapped.__name__ = name
    wrapped.__doc__ = fn.__doc__
    return wrapped


def lab_summary():
    """Print what you've answered, checkpoint by checkpoint."""
    if not _student["email"]:
        print("⚠️  Run the register cell first, then run this cell again.")
        return

    print(f"Lab summary for {_student['name']} <{_student['email']}>")
    print("=" * 60)
    for cp, cfg in _CHECKPOINTS.items():
        items = cfg["items"]
        correct = [i for i in items if _is_correct(i)]
        print(f"\nCheckpoint {cp} — {cfg['title']}: {len(correct)}/{len(items)} correct")
        for i in items:
            if _is_correct(i):
                mark = "✅ correct"
            elif _is_answered(i):
                mark = "❌ not yet — keep trying"
            else:
                mark = "▢  not answered"
            print(f"  {i}  {mark}")

    print("\n" + "=" * 60)
    print("Save this notebook (Ctrl/Cmd + S). Points are tallied by the TA after the lab.")
    if _failed_reports[0]:
        print(f"\n(Note: {_failed_reports[0]} check-in(s) could not reach the TA's sheet —")
        print(" no internet? No problem: your saved notebook covers your work.)")


# Wrap any autograder functions that were loaded before this file.
connect_tests()

if not _configured and __name__ == "__main__" and not _arg:
    print("ee105_checkin loaded (live reporting configured: %s)" % _configured)
