#!/usr/bin/env python
# EE105 Module 1 Lab 2 — autograder for the resistor-network checkpoints.
# Students: you don't need to read or edit this file.
#
# Loaded by the notebook with:  %run autograder.py  followed by  connect_tests()
# Each test raises AssertionError (carrying a hint) when something is off. The
# check-in system wraps these, shows you the hint, and records the result.
import hashlib as _hashlib

import sympy as _sp

# The network: resistor R_k sits between nodes (S_a, S_b), and its current i_k is
# defined as flowing S_a -> S_b (left-to-right / top-to-bottom). `it` is the total
# current the 3.3 V supply pushes into S1; S9 is ground.
_ENDS = {1: (1, 2), 2: (2, 3), 3: (1, 4), 4: (2, 5), 5: (3, 6), 6: (4, 5),
         7: (5, 6), 8: (4, 7), 9: (5, 8), 10: (6, 9), 11: (7, 8), 12: (8, 9)}
_CURRENTS = [f"i{k}" for k in range(1, 13)] + ["it"]
_NETWORK_OHMS = {
    "Network 1": {k: (100 if k in (1, 2, 6, 7, 11, 12) else 50) for k in range(1, 13)},
    "Network 2": {k: 100 for k in range(1, 13)},
}
_SUPPLY = _sp.Rational(33, 10)


def _residuals(equations, what):
    """lhs - rhs of every equation, with floats turned into exact fractions."""
    assert isinstance(equations, (list, tuple)), (
        f"{what} should be a list of equations:  [Eq(..., ...), Eq(..., ...), ...]")
    out = []
    for n, eq in enumerate(equations, 1):
        assert eq is not True and eq != _sp.true, (
            f"Equation {n} says the same thing on both sides (like x = x), so SymPy reduced it to True. "
            "Check for a typo.")
        assert eq is not False and eq != _sp.false, (
            f"Equation {n} can never be true (SymPy reduced it to False). Check for a typo.")
        assert isinstance(eq, _sp.Equality), (
            f"Equation {n} is not an Eq(...). Write each one as  Eq(left side, right side).")
        out.append(_sp.nsimplify(_sp.expand(eq.lhs - eq.rhs), rational=True))
    assert out, f"{what} is empty - add your equations to the list."
    return out


def _node_balance():
    """One row per node S1..S9: +1 for a current flowing in, -1 for one flowing out."""
    rows = []
    for node in range(1, 10):
        row = [0] * 13
        for k, (a, b) in _ENDS.items():
            if b == node:
                row[k - 1] += 1
            if a == node:
                row[k - 1] -= 1
        if node == 1:
            row[12] += 1          # the supply delivers `it` into S1 ...
        if node == 9:
            row[12] -= 1          # ... and it returns through ground at S9
        rows.append(row)
    return _sp.Matrix(rows)


def test_kcl(equations):   # 1.1 — Kirchhoff's current law at every node
    balance = _node_balance()
    full = balance.rank()                                   # 8: nine nodes, one redundant
    rows = []
    for n, res in enumerate(_residuals(equations, "kcl_equations"), 1):
        by_name = {str(sym): sym for sym in res.free_symbols}
        extra = sorted(set(by_name) - set(_CURRENTS))
        assert not extra, (
            f"KCL equation {n} contains {', '.join(extra)}. KCL is about currents only "
            "(i1 ... i12 and it) - node voltages belong to Ohm's law in Checkpoint 2.")
        row = [res.coeff(by_name[c]) if c in by_name else 0 for c in _CURRENTS]
        rebuilt = sum(co * by_name[c] for co, c in zip(row, _CURRENTS) if c in by_name)
        assert _sp.expand(res - rebuilt) == 0, (
            f"KCL equation {n} should just add and subtract currents, e.g. Eq(it, i1 + i3).")
        assert balance.col_join(_sp.Matrix([row])).rank() == full, (
            f"KCL equation {n} does not balance. At each node, currents flowing IN = currents flowing OUT. "
            "Check which currents touch that node and which way each arrow points in the figure.")
        rows.append(row)
    have = _sp.Matrix(rows)
    if have.rank() < full:
        missing = [f"S{node}" for node in range(1, 10)
                   if have.col_join(balance[node - 1, :]).rank() > have.rank()]
        raise AssertionError(
            f"Every equation is correct, but you have {have.rank()} independent KCL equations and this network "
            f"needs {full}. Nodes not covered yet: {', '.join(missing)}.")
    print("KCL equations passed!")


def _ohm_match(res, k):
    """Which networks' resistor value makes `res` a multiple of  i_k*R_k - (s_a - s_b)?  (set of names)"""
    a, b = _ENDS[k]
    by_name = {str(sym): sym for sym in res.free_symbols}
    cur = by_name[f"i{k}"]
    sa, sb = (by_name.get(f"s{n}", _sp.Symbol(f"s{n}")) for n in (a, b))
    known = {"s1": _SUPPLY, "s9": 0}
    ok = set()
    for net, ohms in _NETWORK_OHMS.items():
        value = {by_name[f"r{j}"]: ohms[j] for j in range(1, 13) if f"r{j}" in by_name}   # symbolic r_k is fine
        lhs = res.subs(value)
        ci = lhs.coeff(cur)
        for sub_known in (False, True):                       # s1 / s9 may be symbols or already 3.3 / 0
            va, vb = ((known.get(f"s{n}", sym) if sub_known else sym) for n, sym in ((a, sa), (b, sb)))
            want = cur * ohms[k] - (va - vb)
            if _sp.expand(lhs * ohms[k] - want * ci) == 0 and ci != 0:
                ok.add(net)
    return ok


def test_ohm(equations):   # 2.1 — Ohm's law for every resistor
    seen, nets = {}, set(_NETWORK_OHMS)
    for n, res in enumerate(_residuals(equations, "ohm_equations"), 1):
        names = {str(sym) for sym in res.free_symbols}
        currents = sorted(names & set(_CURRENTS))
        assert len(currents) == 1 and currents[0] != "it", (
            f"Ohm's-law equation {n} should contain exactly one resistor current (it has: "
            f"{', '.join(currents) or 'none'}). One equation per resistor:  i_k * r_k = (voltage drop across R_k).")
        k = int(currents[0][1:])
        a, b = _ENDS[k]
        assert k not in seen, f"Equations {seen[k]} and {n} are both about R{k}. Each resistor needs exactly one."
        seen[k] = n
        match = _ohm_match(res, k)
        assert match, (
            f"Ohm's-law equation {n} (resistor R{k}) is not right. R{k} connects S{a} and S{b}, and i{k} flows "
            f"from S{a} to S{b}, so:  i{k} * r{k} = s{a} - s{b}.  Also check the value you gave r{k}.")
        nets &= match
    missing = [f"R{k}" for k in range(1, 13) if k not in seen]
    assert not missing, f"Correct so far, but no equation yet for: {', '.join(missing)}."
    assert nets, ("Each equation is fine on its own, but the resistor values mix Network 1 and Network 2. "
                  "Re-check r1 ... r12 against the values given for the network you are solving.")
    print("Ohm's-law equations passed!")


# sha256('<net>|<name>|<rounded value>')[:20] for each answer and its two neighbours in the
# last decimal place. Volts are checked to 3 decimals, currents to 0.01 mA.
_ANSWERS = {
    ("net1", "volts"): {
        "s2": ['f222491734c78e2c856c', '952d68101e00853e8644', '63477829ac47c2cd8726'],
        "s3": ['0d3e489f67b83f14a6a3', 'e9bafa469c6111d9d7e7', '544941ac4086941bde34'],
        "s4": ['ad87a6d562237dddd6a0', 'cdc0285172391f39fdb3', '50759dbccc30db45abfc'],
        "s5": ['3f7edb6d8b94b8eb1f90', '587da5036f65face9574', '50150edf92bc2f6dee9d'],
        "s6": ['8bfc64afd7065c693e4e', 'd2d23cfdf9126ca54243', '85ab02546c836be7290e'],
        "s7": ['0bcaa2d623fe6f249f38', 'de1afe27f4cfc7eb03e9', '15380d6497aa54ed2161'],
        "s8": ['d57dd50d239537b574c5', '8b6eba1567859d3f420b', '74389261278a9b4d9a68'],
    },
    ("net1", "amps"): {
        "i1": ['392d2664b17414c19d06', 'b8530d8d519606cfeca7', '96c5f4003002994e9c39'],
        "i2": ['6cf9d439dc645681c558', 'd63fae856f9a410860f7', '59f70e43b967779349b1'],
        "i3": ['7720b12c73d73a2168b5', '5d73efe28ef92233575d', '2ce2a34349e69f7777a9'],
        "i4": ['54c54c126ecc88f476c5', 'ba03a0420e86e260e5eb', '4c912e7e5764b22d5816'],
        "i5": ['f1a82b47b84f899a2469', '4a59652ecee08520459f', '39a4496f45beaf6d7986'],
        "i6": ['e274f36821b15441dcb3', '309d2d7d8ba10b315e55', 'a1295a75f5db927aa8cb'],
        "i7": ['915d69e530d9f01cb9d4', '50af5ac6e9d26a90fcdb', '2677a2bda8d483ae21c7'],
        "i8": ['91941d9b5ed4786f4068', '2bb5249d604161f39d2e', '898d6dd9dbc64789b04e'],
        "i9": ['8aa2191e042e498324c6', '46523ba912e8d52153d3', '47ce6481385b3dc0d610'],
        "i10": ['d06849b0cf14cd863191', '4b9154829f5b0dd553eb', 'b7bb98d518ed6dec0f03'],
        "i11": ['3b3b70cb123867dc0111', 'bc30af2c4e9701d2120f', '6db8e0ae37f83bd90d3d'],
        "i12": ['48d15828366766dc46ac', 'e77a04763a898a8530f4', 'abada82f7ed746a8222a'],
        "it": ['d9f2fed71de8c86e035d', 'e822da85349f135db70f', 'ed2cc2dc8d4bd490ecd5'],
    },
    ("net2", "volts"): {
        "s2": ['871c1d0fb077611d225c', '9fe9dc1a97fcf2f05c22', 'd6ddc1be9cd2296ffa42'],
        "s3": ['33ff6fcf030507babcba', '5fa0351f58157606cb54', 'b73378b62931e70a0ff4'],
        "s4": ['6a471aa3b8f4b843dc90', '2ea7e89fbbce336ebab3', 'e137a47b36ef74f1ceb5'],
        "s5": ['1905f2338ac5021ef20a', 'a58b845f7e9218f5cfa7', 'c194754052072f1aecde'],
        "s6": ['07ebacd846f5548de34c', '7e3a792035710d47d930', '6f26adc6711d8abeee1e'],
        "s7": ['cd7a426f6fdb8037bf80', 'd254167c60da17d405d2', 'cb30159685df611ab7ee'],
        "s8": ['d3a687d228ab16f67014', 'c4bc40631e2efec7682f', 'e52e609416694589a193'],
    },
    ("net2", "amps"): {
        "i1": ['f14382931624efae946c', '34a5c10b4d32634b1981', '020e96bc8b7938a22fb3'],
        "i2": ['a9609be082167ce60f7c', '02e5af1fb8c11894be33', '3ff77b9b5b38b547426c'],
        "i3": ['39820dd1c1d3fbc4cf60', 'b0c1443c6f025e62519d', '174496513ddd7f987f98'],
        "i4": ['92d37c9d2fafe622df1a', '7272cf61cc4f3eb60f85', 'd5172b51b92d27ff0891'],
        "i5": ['c208b124d2a38365dd05', 'ad440e5dd69bc0ab9fa1', '7b809086e071ca451bdb'],
        "i6": ['39dd45520df0cfb2c69e', '9fa5975a51820cc42c42', '57231f47a9a9f0d2566e'],
        "i7": ['c1e3c2873f1e34dcaba9', '4e17122c4890d148eac9', 'f3b0c9b84f92ada827be'],
        "i8": ['1f353bb68319abc1bdac', '20bf19896cc9e09112fa', '670ca9336c58d0d5249e'],
        "i9": ['efc9860546ccc72b5a14', '39684f56906e5a093b60', 'dd405a066cae6fe0e6f2'],
        "i10": ['b0327f078ac1e6dd7be6', '4ff22013da3b118bc515', '60f520087a870355c0f3'],
        "i11": ['b1c68ce41d1fe10458fc', 'cbba452d851f06854e83', '0473ea0681ed96f79f61'],
        "i12": ['cd176f09be0614fb9f6a', '14b7cd4f8fabf49ef092', '118e5d91c1726cd615ff'],
        "it": ['a220b0e4bb2f31a3eac6', '6a9e89b86ed65330257f', '08d43986a8ba3a8894ae'],
    },
}


def _check_solution(solution, net, kind):
    assert isinstance(solution, dict), (
        "Pass the dictionary of substituted results, e.g.  test_network1_voltages(solution_substituted)")
    got = {str(k): v for k, v in solution.items()}
    decimals, scale = (3, 1) if kind == "volts" else (2, 1000)
    wrong, absent = [], []
    for name, accepted in _ANSWERS[(net, kind)].items():
        if name not in got:
            absent.append(name)
            continue
        try:
            value = float(got[name]) * scale
        except (TypeError, ValueError):
            raise AssertionError(
                f"{name} = {got[name]} is not a number yet. Substitute s1 = 3.3 and s9 = 0 first, and pass the "
                "substituted dictionary.") from None
        text = f"{round(value, decimals):.{decimals}f}"
        if text.startswith("-") and float(text) == 0:
            text = text[1:]
        if _hashlib.sha256(f"{net}|{name}|{text}".encode()).hexdigest()[:20] not in accepted:
            wrong.append(name)
    assert not absent, f"Your solution has no value for: {', '.join(absent)}. Did solve() get all 20 unknowns?"
    label = "node voltages" if kind == "volts" else "branch currents"
    assert not wrong, (
        f"Not matching for this network: {', '.join(wrong)} ({len(_ANSWERS[(net, kind)]) - len(wrong)} of "
        f"{len(_ANSWERS[(net, kind)])} {label} match). Re-check the resistor values and the equations that "
        "involve those symbols.")
    print(f"{label} passed!")


def test_network1_voltages(solution):   # 4.1
    _check_solution(solution, "net1", "volts")


def test_network1_currents(solution):   # 4.2
    _check_solution(solution, "net1", "amps")


def test_network2_voltages(solution):   # 4.3
    _check_solution(solution, "net2", "volts")


def test_network2_currents(solution):   # 4.4
    _check_solution(solution, "net2", "amps")
