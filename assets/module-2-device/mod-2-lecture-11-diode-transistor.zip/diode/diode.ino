#include <Arduino.h>
#include "AD5593R.h"
#include <Wire.h>

#define m2_diode A2   // Module 2 Diode
#define dac_diode 0   // DAC diode

#define vref 3.3        // reference is 3.3 V

const float dac_conversion = 2.0*vref/4095.0;
const float adc_conversion = vref/1023;
int dac_3p3v = 3.3/dac_conversion;

void setup() {
  Wire.begin();
  Serial.begin(115200);
  dac_setup();
}

void loop() {
  // m2_diode_discrete();
  
  // Serial.print(dac_conversion, 6);
  // Serial.print(",");
  // Serial.println(dac_3p3v);
  // delay(1000);

 m2_diode_sweep();
 delay(10000);
}

void m2_diode_discrete(){  
  float dac_voltage = 2.5;
  int inc = dac_voltage/dac_conversion;  
  setDACVal(dac_diode, inc);
  float resistor_voltage = (analogRead(m2_diode)*adc_conversion);
  Serial.println("Diode current in (mA), DAC Voltage (V), Diode Voltage(V)");
  Serial.print(resistor_voltage);
  Serial.print(",");
  Serial.print(dac_voltage);
  Serial.print(",");
  Serial.println(dac_voltage-resistor_voltage);  
}

void m2_diode_sweep(){
  Serial.println("Make sure that module 2 is active");
  int inc_interval = 10;
  int inc_delay = 1;
  int inc = 0;
  unsigned long prev_inc_time = 0;

  Serial.println("Diode current in (mA), DAC Voltage (V), Diode Voltage(V)");
  while(1){
    if((inc <= dac_3p3v) && (millis() - prev_inc_time > inc_delay)){
      prev_inc_time = millis();
      setDACVal(dac_diode, inc);
      float resistor_voltage = (analogRead(m2_diode)*adc_conversion);
      Serial.print(resistor_voltage);
      Serial.print(",");
      float dac_voltage = inc*dac_conversion;
      Serial.print(dac_voltage);
      Serial.print(",");
      Serial.println(dac_voltage-resistor_voltage);
      inc = inc + inc_interval;
    }
    if((inc >= dac_3p3v) && (millis() - prev_inc_time > inc_delay)){
       prev_inc_time = millis();
       setDACVal(dac_diode, 0);
       inc = 0;
       break;
    }
  }
}


void dac_setup(){
  initADAC(0x10, 1, 1);
  setDACGain(1);
  setDACpin(dac_diode);
}

void reset_dac(){
  setDACVal(dac_diode,0);
}
