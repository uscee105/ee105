// #include "arduino_secrets.h"

#include <Arduino.h>
#include "AD5593R.h"
#include <Wire.h>

#define m2_nmos A3    // Module 2 NMOS
#define dac_diode 0         // DAC diode
#define dac_nmos_gate 1     // NMOS Gate
#define dac_nmos_drain 2    // NMOS Drain

#define vref 3.3        // reference is 3.3 V

const float dac_conversion = 2.0*vref/4095.0;
const float adc_conversion = vref/1023;
int dac_3p3v = 3.3/dac_conversion;

void setup() {
  Wire.begin();
  Serial.begin(115200);
  dac_setup();
  float vds = Serial.parseInt();   // Read number
}

void loop() {
  // comment out one of them
  
  // use this for discrete reads
  // float gate_vol = 0.9; // (V)
  // float drain_vol = 0.7; // (V)
  // discrete_read(gate_vol, drain_vol);

  // use this for voltage sweeping
  voltage_sweeping_vgs();
  // voltage_sweeping_vds();
  
}

void m2_tran_module_vd_sweep(float vgs){
  Serial.println("Vgs | Vds | Ic");
  // for(int k = 0; k <= 2000; k = k + 200){
    int k = vgs / dac_conversion;
    setDACVal(dac_nmos_gate, k);
    for(int i = 0; i <= 2000; i = i + 10){
      setDACVal(dac_nmos_drain, i);
      Serial.print(vgs);
      Serial.print(", ");
      Serial.print(i*dac_conversion);
      Serial.print(", ");
      Serial.println(analogRead(m2_nmos)*adc_conversion);
      delay(5);
    }
  // }
  Serial.println("Copy and paste measurement data to a .csv file");
}

void m2_tran_module_vg_sweep(float vds){
  Serial.println("Vds | Vgs | Ic");
  // for(int k = 0; k <= 2000; k = k + 200){
    int k = vds / dac_conversion;
    setDACVal(dac_nmos_drain, k);
    for(int i = 0; i <= 2000; i = i + 10){
      setDACVal(dac_nmos_gate, i);
      Serial.print(vds);
      Serial.print(", ");
      Serial.print(i*dac_conversion);
      Serial.print(", ");
      Serial.println(analogRead(m2_nmos)*adc_conversion);
      delay(5);
    }
  // }
  Serial.println("Copy and paste measurement data to a .csv file");
}

void discrete_read(float gate_vol, float drain_vol){
  int gate_vol_inp = gate_vol/dac_conversion;
  int drain_vol_inp = drain_vol/dac_conversion;
  setDACVal(dac_nmos_gate, gate_vol_inp);
  setDACVal(dac_nmos_drain, drain_vol_inp);
  Serial.print("gate voltage :");
  Serial.print(gate_vol, 5);
  Serial.print(", ");
  Serial.print("drain voltage :");
  Serial.print(drain_vol, 5);
  Serial.print(", ");
  Serial.print("current :");
  Serial.println(analogRead(m2_nmos)*adc_conversion);
  delay(2000);
}

void voltage_sweeping_vds(){
  
  // Voltage Sweeping
  Serial.println("READY");
  while (!Serial.available()) {
    // block until Python sends something
  }

  float vgs = Serial.parseFloat();
  // Drain any leftover newline/whitespace
  while (Serial.available()) Serial.read();

  m2_tran_module_vd_sweep(vgs);
  delay(500);
}

void voltage_sweeping_vgs(){
  
  // Voltage Sweeping
  Serial.println("READY");
  while (!Serial.available()) {
    // block until Python sends something
  }
  float vds = Serial.parseFloat();
  
  // Drain any leftover newline/whitespace
  while (Serial.available()) Serial.read();

  m2_tran_module_vg_sweep(vds);
  delay(500);
}

void dac_setup(){
  initADAC(0x10, 1, 1);
  setDACGain(1);
  setDACpin(dac_nmos_gate);
  setDACpin(dac_nmos_drain);
}

void reset_dac(){
  setDACVal(dac_nmos_gate,0);
  setDACVal(dac_nmos_drain,0);
}

void press_enter_to_continue(){
  while (Serial.available() == 0) {
    // This loop does nothing but wait
  }

  // Read and discard any characters until a newline is found
  while (Serial.read() != '\n') {
    // This loop discards all characters before the 'Enter' press
  }
}



